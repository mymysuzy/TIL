CREATE TABLE IF NOT EXISTS `user` (
  `user_id` varchar(20) DEFAULT NULL UNIQUE KEY,
  `user_email` varchar(30) NOT NULL PRIMARY KEY,
  `user_password` varchar(20) ,
  `user_desc` varchar(200),
  `user_pic` varchar(40) DEFAULT 'defaultProfileImage.jpg',
  `user_cbti` varchar(10),
  `user_total_score` int(11) DEFAULT 0,
  `user_authKey` varchar(20),
  `user_authStatus` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

drop table user;
select * from user;
INSERT INTO user(user_id, user_email, user_password,  user_cbti ) 
values ('user_id', 'user@mail.com', 'user_password', 'user_cbti');

CREATE TABLE IF NOT EXISTS `pheed` (
  `pheed_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `pheed_user_id` varchar(20) NOT NULL,
  `pheed_title` varchar(200) NOT NULL,
  `pheed_content` varchar(1000) NOT NULL,
  `pheed_pic` varchar(200),
  `pheed_date` timestamp NOT NULL DEFAULT current_timestamp(),
   FOREIGN KEY (`pheed_user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;


CREATE TABLE `pheed_pic` (
    pheedPicId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    pheedId INT NOT NULL,
    originalName VARCHAR(260) NOT NULL,
    saveName VARCHAR(40) NOT NULL,
    size INT NOT NULL,
    deleteYn ENUM('Y', 'N') NOT NULL DEFAULT 'N',
    insertTime DATETIME NOT NULL DEFAULT NOW(),
    deleteTime DATETIME NULL
);

CREATE TABLE IF NOT EXISTS `follow` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `following` varchar(30) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `followers` varchar(30) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `temp_followers` varchar(100) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`follow_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE if NOT EXISTS `inquiry` (
    inquiry_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    inquiry_user_id VARCHAR(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
    inquiry_user_email VARCHAR(30) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
    inquiry_title VARCHAR(200) COLLATE utf8mb3_unicode_ci NOT NULL,
    inquiry_content VARCHAR(1000) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
    inquiry_pic varchar(200) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
   inquiry_date timestamp NOT NULL DEFAULT current_timestamp(),
    KEY inquiry_user_id (inquiry_user_id),
    CONSTRAINT inquiry_ibfk_1 FOREIGN KEY (inquiry_user_id) REFERENCES user(user_id) ON DELETE CASCADE ON UPDATE cascade
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE if NOT EXISTS `inquiry_comment`(
	 comment_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	 comment_inquiry_id INT NOT NULL ,
	 comment_content VARCHAR(3000) NOT NULL ,
	 comment_writer VARCHAR(20) NOT NULL ,
	 comment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP() ,
	 comment_update_time DATETIME DEFAULT NULL ,
	 KEY comment_inquiry_id (comment_inquiry_id),
    CONSTRAINT fk_comment_inquiry_id FOREIGN KEY (comment_inquiry_id) REFERENCES inquiry (inquiry_id) ON DELETE CASCADE ON UPDATE cascade
	 );
     
CREATE TABLE IF NOT EXISTS `notice` (
  notice_id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  notice_title varchar(200) COLLATE utf8mb3_unicode_ci NOT NULL,
  notice_content varchar(1000) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  notice_pic varchar(200) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  notice_date timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `decoration`(
		decoration_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		originalName VARCHAR(260) NOT NULL,
		saveName VARCHAR(40) NOT NULL,
		size INT NOT NULL,
		insert_time DATETIME NOT NULL DEFAULT NOW()
	)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
     
CREATE TABLE IF NOT EXISTS `scrap` (
  scrap_id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  scrap_user_id varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  scrapnotice_pheed_id varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  scrap_title varchar(200) COLLATE utf8mb3_unicode_ci NOT NULL,
  scrap_content varchar(1000) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  scrap_pic varchar(200) COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

use CAMEO;
DESC scrap;

CREATE TABLE `crawling` (
  `cafe_name` varchar(20) COLLATE utf8mb3_unicode_ci NOT NULL PRIMARY KEY,
  `address` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  `opening_hours` varchar(20) COLLATE utf8mb3_unicode_ci,
  `number` int(20) COLLATE utf8mb3_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;